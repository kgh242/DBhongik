﻿<?php

//DB 연결
//mysqli_connect(db주소, id, password, db명);
$conn = mysqli_connect("localhost", "root", "1234", "test");

//인코딩 설정
//MySQL이 utf8로 설정되어 있을 경우 아래와 같이 인코딩 설정을 해준다.
//안해줄 경우 한글깨짐 현상이 나타난다.
mysqli_set_charset($conn, "utf8");

 
$A=$_POST["TextBox011"];
$B=$_POST["TextBox012"];
$C=$_POST["TextBox013"];
$D=$_POST["TextBox014"];



if( $A=="" and $B=="" and $C=="" and $D==""){
	
	$query = "select * from AG";
}

else
{
	$query = "select * from AG where `A#`='$A' or `G#` = '$B' or `A_QTY` ='$C' or `A_SALES` ='$D' ";
}


//쿼리실행
//mysqli_query(db연결객체, 쿼리문);
$stid = mysqli_query($conn, $query) or die('ex');

//DB연결해제
mysqli_close($conn);
?>


<html>
	<head>
		<title>results</title>
	</head>
	
	<STYLE TYPE="text/css">
			<!--
			.background{background-image:url("BG2.png" ); background-repeat:repeat}
			.font1{font-family:µ¸¿ò; font-size:15pt; font-family:cursive;
			font-weight:bold;color:green;width:100%;height:23;
			Filter:Shadow(color=f0e68c,direction=125); text-align:left}
			.font2{font-size:15pt; font-family: µ¸¿ò; color:#2f8bef}
			.font3{font-size:12pt; font-family: µ¸¿ò; color:#808080}
			//-->
	</STYLE>

	<body BACKGROUND = "BG2.png">
		<BR>
		<BR>
		<TABLE BORDER="0" ALIGN="CENTER">
			<TR>
				<TD>
					<FONT CLASS="font1">
						Search Result
					</FONT>
				</TD>
			<TR>
		</TABLE>
		
		<BR>

			<TABLE BORDER="1" ALIGN="center">
					<TR>
						<TD>
						A#
						</TD>
						<TD>
						G#
						</TD>
						<TD>
						A_QTY
						</TD>	
						<TD>
						A_sales
						</TD>	
					</TR>
<?php
	//while($row=oci_fetch_array($stid,OCI_BOTH))

	//DB결과값을 뿌려준다.
	//mysqli_fetch_array(db결과 리소스, 결과타입)
	//결과타입
	//MYSQLI_ASSOC : value를 key값으로 찾는다. | ex)$row["a#"]
	//MYSQLI_NUM : value를 번호로 찾는다. | ex)$row[0]
	//MYSQLI_BOTH : MYSQLI_ASSOC, MYSQLI_NUM 두가지 혼용
	while($row=mysqli_fetch_array ($stid,MYSQLI_BOTH))	
	{
		echo "<tr>
				<td>".$row[0]."</td>
				<td>".$row[1]."</td>
				<td>".$row[2]."</td>
				<td>".$row[3]."</td>
			</tr>";
	}
?>
			</TABLE>
	</body>
</html>
