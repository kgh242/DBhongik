﻿<?php
ini_set('display_errors',1);

$A=$_POST["TextBox101"];


//DB 연결
//mysqli_connect(db주소, id, password, db명);
$conn = mysqli_connect("localhost", "root", "1234", "test");

//인코딩 설정
//MySQL이 utf8로 설정되어 있을 경우 아래와 같이 인코딩 설정을 해준다.
//안해줄 경우 한글깨짐 현상이 나타난다.
mysqli_set_charset($conn, "utf8");


//MySQL에서는 컬럼명에 ` 기호를 사용하면 금지된 문자도 컬럼명으로 쓸 수 있다.
	//여기서는 #이 금지된 문자이다.
$query1 = "delete from Agency where `A#` = '$A'";

//쿼리실행
//mysqli_query(db연결객체, 쿼리문);
mysqli_query($conn, $query1) or die('ex');


echo '1';

//DB연결해제
mysqli_close($conn);
?>


<script>
window.open('D_agency.html','second');
</script>