﻿<?php

$A=$_POST["TextBox022"];

//DB 연결
//mysqli_connect(db주소, id, password, db명);
$conn = mysqli_connect("localhost", "root", "1234", "test");

//인코딩 설정
//MySQL이 utf8로 설정되어 있을 경우 아래와 같이 인코딩 설정을 해준다.
//안해줄 경우 한글깨짐 현상이 나타난다.
mysqli_set_charset($conn, "utf8");


$query1 = "delete from Goods where `G#`= '$A'";						

//쿼리실행
//mysqli_query(db연결객체, 쿼리문);
mysqli_query($conn, $query1) or die('ex');

//DB연결해제
mysqli_close($conn);
?>


<script>
window.open('D_goods.html','second');
</script>