﻿<?php
ini_set('display_errors',1);

//DB 연결
//mysqli_connect(db주소, id, password, db명);
$conn = mysqli_connect("localhost", "root", "1234", "test");

//인코딩 설정
//MySQL이 utf8로 설정되어 있을 경우 아래와 같이 인코딩 설정을 해준다.
//안해줄 경우 한글깨짐 현상이 나타난다.
mysqli_set_charset($conn, "utf8");


$A=$_POST["TextBox031"];
$B=$_POST["TextBox032"];
$D=$_POST["TextBox034"];
$E=$_POST["TextBox035"];

if($A!=""){
	$query1 = "update Company set `C#`='$A' where `AREA` = '$E'";
}
if($B!=""){
	$query2 = "update Company set `C_QTY`='$B' where `AREA` = '$E'";
}
if($D!=""){
	$query3 = "update Company set `YEAR`='$D' where `AREA` = '$E'";
}

//쿼리실행
//mysqli_query(db연결객체, 쿼리문);
if($query1 != "") mysqli_query($conn, $query1) or die('ex');
if($query2 != "") mysqli_query($conn, $query2) or die('ex');
if($query3 != "") mysqli_query($conn, $query3) or die('ex');

echo '1';

//DB연결해제
mysqli_close($conn);
?>



<script>
window.open('U_company.html','second');
</script>